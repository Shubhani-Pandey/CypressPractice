const newAdminName = 'Sania Shaheen'
const newAdminPwd = 'ABc123#@'

export class userManipulation{
        addDetails(newUserName){
            cy.get('#btnAdd').click();
            cy.get('#systemUser_userType').select('Admin').should('value','1');
            cy.get('#systemUser_employeeName_empName').clear().type(newAdminName);
            cy.get('#systemUser_userName').type(newUserName);
            cy.get('#systemUser_status').select('Enabled').should('value','1');
            cy.get('#systemUser_password').clear().type(newAdminPwd);
            cy.get('#systemUser_confirmPassword').clear().type(newAdminPwd);
            cy.get('#btnSave').click();
        }
        searchUser(newUserName){
            cy.get('#searchSystemUser_userName').type(newUserName);
            cy.get('#searchSystemUser_userType').select('Admin').should('value','1');
            cy.get('#searchSystemUser_employeeName_empName').type(newAdminName);
            cy.get('#searchSystemUser_status').select('Enabled').should('value','1');
            cy.get('#searchBtn').click();
        }
        delUser(newUserName){
            cy.xpath("//td[normalize-space() ='" + newUserName + "']/preceding-sibling::td").click()
            cy.get('#btnDelete').click();
            cy.get('#dialogDeleteBtn').click();
        }
}
export const manipulate = new userManipulation()
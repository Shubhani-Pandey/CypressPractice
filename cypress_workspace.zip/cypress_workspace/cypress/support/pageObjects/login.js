const username = 'Admin'
const password = 'admin123'

export class login{
   siteLogin()
   {
      cy.visit('/auth/login')
      cy.get('#txtUsername').type(username);
      cy.get('#txtPassword').type(password);
      cy.get('#btnLogin').click();
      cy.get('#welcome').invoke('text').then(text=>
      expect(text).to.match(/^Welcome\s.*/))
   }
}
export const loginAction = new login()
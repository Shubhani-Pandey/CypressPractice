import { login, loginAction } from "../../support/pageObjects/login";
import { directoryTab } from "../../support/pageObjects/navigation"

const name = 'Odis Adalwin'
const jobTitle = 'Chief Technical Officer'
const location = 'HQ-CA, USA'

describe("user profile manipulation",()=>{
    beforeEach("cookie_preserve",() => Cypress.Cookies.preserveOnce('orangehrm'))
    before("login",() => loginAction.siteLogin())
       it("Navigate to directory tab and search",() => {
           directoryTab();
           cy.get('#searchDirectory_emp_name_empName').clear().type(name);
           cy.get('#searchDirectory_job_title').select('Chief Technical Officer').should('have.value','3');
           cy.get('#searchDirectory_location').select('HQ - CA, USA').should('have.value','1');
           cy.get('#searchBtn').click();
           cy.get('.odd').find('li').invoke('text').should('contain',name);
        })
})
import { login, loginAction } from "../../support/pageObjects/login";
import {adminTab, pimTab, leaveTab } from "../../support/pageObjects/navigation.js"
import { manipulate} from "../../support/pageObjects/userOp"

const uuid = () => Cypress._.random(0, 1e6)
const newUserName = uuid()

describe("user profile manipulation",()=>{
    beforeEach("cookie_preserve",() => Cypress.Cookies.preserveOnce('orangehrm'))
    before("login",() => loginAction.siteLogin() );
    it("naviagate to admin tab",() => adminTab())
    it("Add user",() =>{
         manipulate.addDetails(newUserName);
         cy.get('.message.success.fadable').should('contain','Successfully Saved');
        })
    it("Search user",() => {
        manipulate.searchUser(newUserName);
        cy.get('#resultTable').find('a').invoke('text').should('contain',newUserName);
    })
    it("Delete user",() => {
        manipulate.delUser(newUserName);
        cy.get('.message.success.fadable').should('contain','Successfully Deleted');
    })
})
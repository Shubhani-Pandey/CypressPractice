import { loginAction } from "../../support/pageObjects/login"
import { adminTab, pimTab } from "../../support/pageObjects/navigation";

describe("Testing PIM functionalities",()=>{
    beforeEach("Preserve Cookies",()=> Cypress.Cookies.preserveOnce("orangehrm"));
    before("login",()=> loginAction.siteLogin());
    it("csv data import test",()=>{
        pimTab();
        cy.get('#menu_pim_Configuration').should('be.visible').click({force:true});
        cy.get('#menu_admin_pimCsvImport').click({force:true});
        cy.get('#pimCsvImportHeading').should('have.text','CSV Data Import');
        cy.get('#pimCsvImport_csvFile').attachFile('importData.csv');
        cy.get('#btnSave').click();
        cy.get('#btnSave').should('have.value','Processing');
    })
})
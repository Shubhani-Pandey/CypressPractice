/// <reference types="cypress"/>

const { values } = require("cypress/types/lodash")

describe('Our first test case',()=>{
    it('access elements',()=>{
        // by tag name
        // cy.get('input')

        // by id use #...by class use .apply[here single class name out of all mentioned will wo]

        // by attribute 
        // cy.get('[placeholder]')

        // by attribute name and values
        // cy.get('[placeholder="Email"]')

        // by class values  ...here complete class name required
        // cy.get('[class="lalaal"]')

        //by tag name and attribute with value
        //cy.get('input[placeholder="Email"]')

        //by two different attributes
        //cy.get('[placeholder="Emial"][type="emial"]')
       
        //by tag and attribute, id and class 
        //cy.get('input[placeholder="email"]#id.class')

        //cypress recommended
        //cy.get('[data-cy="inputEmail"]]')

        //contains('','')...we can use many values in contains

        //find method is used to find child element insdie parent

        //check is only used with checkboxes and radio buttons ...we can check the chekbox utcant uncheck it using check....to uncheck it use click
    
    })
})
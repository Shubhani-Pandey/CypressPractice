describe("iframes ,alerts,multiple windows",()=>{
    it("iframes",()=>{
        cy.visit('https://the-internet.herokuapp.com/iframe');
        cy.get('#mce_0_ifr').then(($el)=>{
            let body;
            body = $el.contents().find('body');              //contents and body are the functions offered by jquery
            cy.wrap(body).clear().type('Hello vello')        //type function is offered by cypress. we could have used text() that is supported by jquery
        })
    });
    it("alerts",()=>{
        cy.visit('https://the-internet.herokuapp.com/javascript_alerts');
        cy.on('window:alert',alertText=>{
            cy.expect(alertText).eq('I am a JS Alert')
        })
        cy.get('button').contains('Click for JS Alert').click();
    });
    it("js confirm alert",()=>{        
        cy.visit('https://the-internet.herokuapp.com/javascript_alerts');
        cy.on('window:confirm',alertText=>{   //window:confirm is a event listener
            cy.expect(alertText).eq('I am a JS Confirm')
            return false;      //by default true ..therefor clicks on OK to ..click om cancel...return false
        })

        // cy.window().then($el=>{
        //     cy.stube($el,'confirm').returns(false)            write own stubbing function...same as aboveone
        // })
        cy.get('button').contains('Click for JS Confirm').click();
    });
    it("js prompt",()=>{        
        cy.visit('https://the-internet.herokuapp.com/javascript_alerts');
        cy.window().then($el=>{
            cy.stub($el,'prompt').returns('hello');   //on was a stub in background
        });
        cy.get('button').contains('Click for JS Prompt').click();
    });
    it.only("multiple windows",()=>{        
        cy.visit('https://the-internet.herokuapp.com/windows');
        cy.get('a').contains('Click Here').invoke('removeAttr','target').click();  //removing this attr can lead to open another window
        //cy.get('a').contains('Click Here').click();      //but only this will open new window out of our reach
        cy.get('h3').should('have.text','New Window');

        //if another window has a diff domain...we need to change configuratiins and make chromewebsecurity=false
    });

    //hooks-> beforeeach,before(beforeall->executed only once),after,aftereach


})




    

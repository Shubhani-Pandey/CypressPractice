describe("Testing form",()=>{
    it("open form",()=>{
        cy.visit('https://www.demoqa.com/automation-practice-form/')
    });
    it("enter deatils",()=>{
        cy.get('[id="firstName"]').should('be.visible').should('be.enabled').type('Shubhani')   //#firstName
        cy.get('[id="lastName"]').should('be.visible').should('be.enabled').type('Pandey')
        cy.get('[id="userNumber"]').should('be.visible').should('be.enabled').type('9953675154')
        cy.get('[id="userEmail"]').should('be.visible').should('be.enabled').type('shubhani.pandey@incedoinc.com')
    });
})




    

describe("buttons and dropdowns",()=>{
    it("radio buttons",()=>{
        cy.get("[id='gender-radio-1']").should('not.be.checked').click({force: true}).should('be.enabled')
        //cy.get("[id='gender-radio-1']").should('not.be.checked').check({force: true})
        //cy.get("[for='gender-radio-1']").should('not.be.checked').click()   because label was overlapping the button
        // force:true was added because same name was repeated 
        // method1-> //input[@id='gender-radio-1']
        // method2-> //*[@id='gender-radio-1']
        // method3-> #gender-radio-1
        // method4-> .classname#idname
        // method5-> [id='gender-radio-1']
        //use indexing of web elements only as a last resort
    });
    it("checkboxes",()=>{
        cy.get('#hobbies-checkbox-1').should('be.enabled').click({force: true})
    });
    it("buttons",()=>{
        cy.visit('https://www.demoqa.com/buttons')
        cy.get('button').contains(/^Click Me$/).click()       //use regex when not unique
        cy.get('button').contains('Double Click Me').dblclick()
        //cy.get('#doubleClickMessage').should('have.text','You have done a double click') //assert text

        cy.get('#doubleClickMessage').should(($web_element)=>{
            expect($web_element.text()).equal('You have done a double click')
        })
    });

    it("dropdown",()=>{
        cy.visit('https://the-internet.herokuapp.com/dropdown')
        cy.get('#dropdown').select('Option 1').should('value','1')  
        //above approach can be followed if we want to assert text intead of value
        });

    it("tables",()=>{
        cy.visit('https://www.demoqa.com/webtables')
        //div[text()='Kierra']/following-sibling::div[4]   x-path for table
        cy.xpath('//div[text()="Alden"]/following-sibling::div[6]//span[@id="delete-record-2"]').click();
        cy.get('.rt-td').contains('Cierra').siblings().eq(3).should('have.text','10000'); //classname starts with .
    });
    it("drag and drop",()=>{
        cy.visit('https://the-internet.herokuapp.com/drag_and_drop');
        cy.get('#column-a').drag('#column-b');
        //.get('path',{timeout:3000})     this way we can specify timeout
        cy.xpath('//div[contains(@id,"column-a")]/header').should('have.text','B');
    });
    it("file upload",()=>{
        cy.visit('https://the-internet.herokuapp.com/upload');
        cy.get('#file-upload').attachFile('example.json')
    });
    it("iframes",()=>{
        cy.visit('https://the-internet.herokuapp.com/iframe');
        cy.get('#mce_0_ifr').then(($el)=>{
            let body;
            body = $el.contents().find('body');              //contents and body are the functions offered by jquery
            cy.wrap(body).clear().type('Hello vello')        //type function is offered by cypress. we could have used text() that is supported by jquery
        })
    });
    it("alerts",()=>{
        cy.visit('https://the-internet.herokuapp.com/javascript_alerts');
        cy.on('window:alert',alertText=>{
            cy.expect(alertText).eq('I am a JS Alert')
        })
        cy.get('button').contains('Click for JS Alert').click();
    });
    it("js confirm alert",()=>{        
        cy.visit('https://the-internet.herokuapp.com/javascript_alerts');
        cy.on('window:confirm',alertText=>{   //window:confirm is a event listener
            cy.expect(alertText).eq('I am a JS Confirm')
            return false;      //by default true ..therefor clicks on OK to ..click om cancel...return false
        })

        // cy.window().then($el=>{
        //     cy.stube($el,'confirm').returns(false)            write own stubbing function...same as aboveone
        // })
        cy.get('button').contains('Click for JS Confirm').click();
    });
    it("js prompt",()=>{        
        cy.visit('https://the-internet.herokuapp.com/javascript_alerts');
        cy.window().then($el=>{
            cy.stub($el,'prompt').returns('hello');   //on was a stub in background
        });
        cy.get('button').contains('Click for JS Prompt').click();
    });
    it.only("multiple windows",()=>{        
        cy.visit('https://the-internet.herokuapp.com/windows');
        cy.get('a').contains('Click Here').invoke('removeAttr','target').click();  //removing this attr can lead to open another window
        //cy.get('a').contains('Click Here').click();      //but only this will open new window out of our reach
        cy.get('h3').should('have.text','New Window');

        //if another window has a diff domain...we need to change configuratiins and make chromewebsecurity=false
    });


})




    

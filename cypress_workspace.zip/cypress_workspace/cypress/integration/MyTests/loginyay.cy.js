//constants
const username = 'Admin'
const password = 'admin123'
const success = 200


beforeEach(() => {
    Cypress.Cookies.preserveOnce('session_id', 'remember_token')
})

//test function
describe("ATTEMPTING LOGIN",()=>{

    it("csrf implementation",()=>{
      
        Cypress.Commands.add('loginByCSRF', () => {
          cy.request({
                        method: 'POST',
                        url: '/auth/login',
                        failOnStatusCode: false, 
                        form: true, 
                        body: {
                                username,
                                password,
                                _csrf: csrfToken, 
                            },
                    })
        })

        cy.request('/auth/login')
        .its('body')
        .then((body) => {
          const $html = Cypress.$(body)
          const csrf = $html.find('input[name=_csrf_token]').val()

         cy.loginByCSRF()
          .then((resp) => {
            expect(resp.status).to.eq(success)

          })
        })
        
});

})

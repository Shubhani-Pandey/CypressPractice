describe('Sorting table',() => {
    it('should sort table and assert',()=>{
        cy.visit('https://the-internet.herokuapp.com/tables')
        arr=[]
        cy.get('td.last_name').each(($ele,index,list)=>{
            arr.push($ele)
        })
        cy.get('#table2')
        .find('th').eq(0)
        .click()

        cy.get('td.last_name').each(($ele,index,list)=>{
            expect($ele.text()).to.eql(arr.sort()[index])
        })
    })
})